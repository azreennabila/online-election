/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlineelectionsystem;

/**
 *
 * @author User
 */
public class CastVote {
    
     private int castvote;

    public CastVote(int castvote) {
        this.castvote = castvote;
    }

    public CastVote() {
    }

    public int getCastvote() {
        return castvote;
    }

    public void setCastvote(int castvote) {
        this.castvote = castvote;
    }
    
    public int castingVotesP(Candidate[] candidates, int candidateCount, int voting ){
        
        int cast, castcheck=0;
        
        for(int i=0; i<candidateCount; i++ ){
            if(voting==candidates[i].getPosition().getpId()){
                if(candidates[i].getPosition().getPost_name().equals("President")){
                    
                    cast = candidates[i].getCastVote().getCastvote();
                    candidates[i].getCastVote().setCastvote(cast+1);  
                    castcheck=1;
                }
            }
        }
        
        if(castcheck==0){
            System.out.println("Invalid Position ID");
        }
        
        return castcheck;
        
    }
    
    public int castingVotesVP(Candidate[] candidates, int candidateCount, int votingVP ){

        int castVP, castcheck=0;
        for(int i=0; i<candidateCount; i++ ){
            
            if(votingVP==candidates[i].getPosition().getpId()){
                if(candidates[i].getPosition().getPost_name().equals("Vice President")){
                    
                    castVP = candidates[i].getCastVote().getCastvote();
                    candidates[i].getCastVote().setCastvote(castVP+1);  
                    castcheck=1;
                }
            } 

        }
        
        if(castcheck==0){
            System.out.println("Invalid Position ID");
        }
        
        return castcheck;

    }
    
    public void displayPresidentResults(Candidate[] candidates, int candidateCount){

        int j=0;

        for (int i = 0; i < candidateCount; i++) {

            if(candidates[i].getPosition().getPost_name().equals("President")){
                System.out.println("Candidate " + (j + 1) + ":");
                System.out.println("Matric ID: " + candidates[i].getCand_IDMatric());
                System.out.println("Name: " + candidates[i].getCand_Name());
                System.out.println("Course: " + candidates[i].getCcandidate().getCourseName());
                System.out.println("Position: " + candidates[i].getPosition().getPost_name());
                System.out.println("Position ID: " + candidates[i].getPosition().getpId());
                System.out.println("----------------------------");
                System.out.println("Total Vote: " + candidates[i].getCastVote().getCastvote());
                System.out.println("");

                j++;
            }
        } 
            
    }
    
    public void displayVicePresidentResults(Candidate[] candidates, int candidateCount){

        int j=0;

        for (int i = 0; i < candidateCount; i++) {

            if(candidates[i].getPosition().getPost_name().equals("Vice President")){
                System.out.println("Candidate " + (j + 1) + ":");
                System.out.println("Matric ID: " + candidates[i].getCand_IDMatric());
                System.out.println("Name: " + candidates[i].getCand_Name());
                System.out.println("Course: " + candidates[i].getCcandidate().getCourseName());
                System.out.println("Position: " + candidates[i].getPosition().getPost_name());
                System.out.println("Position ID: " + candidates[i].getPosition().getpId());
                System.out.println("----------------------------");
                System.out.println("Total Vote: " + candidates[i].getCastVote().getCastvote());
                System.out.println("");

                j++;
            }
        } 
            
    }  
    
}
