/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlineelectionsystem;

/**
 *
 * @author User
 */
public class Voter extends User{
    
     public CourseVoter CVote;

    public Voter(CourseVoter CVote, String Id_num) {
        super(Id_num);
        //aggregation
        this.CVote = CVote;
    }

    public Voter(String Id_num) {
        super(Id_num);
    }
    
    public CourseVoter getCVoter(){
        return CVote;
    }
    
}
