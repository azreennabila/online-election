/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlineelectionsystem;

/**
 *
 * @author User
 */
public class User {
    
    protected String Id_num;

    public User() {
    }

    public User(String Id_num) {
        this.Id_num = Id_num;
    }

    public String getId_num() {
        return Id_num;
    }

    public void setId_num(String Id_num) {
        this.Id_num = Id_num;
    }   
    
    public int checkLogIn(){
        int log=1;          
        return log;    
    }
    
}
