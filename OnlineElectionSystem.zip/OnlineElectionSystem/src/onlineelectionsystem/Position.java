/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlineelectionsystem;

/**
 *
 * @author User
 */
public class Position {
    
    private String post_name;
    private int pId;
    
    public Position(){

    }

    public Position(String post_name, int pId) {
        this.post_name = post_name;
        this.pId = pId;
    }

    public String getPost_name() {
        return post_name;
    }

    public int getpId() {
        return pId;
    }

    public void setPost_name(String post_name) {
        this.post_name = post_name;
    }

    public void setpId(int pId) {
        this.pId = pId;
    }
    
    public void PrintPositions(){
        System.out.println("1- President 2023/2024");
        System.out.println("   Description : Responsible for leading and managing the organization.");
        System.out.println("2- Vice President 2023/2024");
        System.out.println("   Description : Assists the president and takes over their duties in their absence.");
    }
    
}
