/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package onlineelectionsystem;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author User
 */
public class HeadAdminPage extends javax.swing.JFrame {

    /**
     * Creates new form HeadAdminPage
     */
    public HeadAdminPage() {
        initComponents();
        getConnection();
        getMostVotedCandidates();
        Show_Data_In_Table(jTableDataP);
        
        
        filterComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                filterData();
            }
        });
    }

    
    public Connection getConnection(){
        Connection con = null;
        
        try {
            con =  DriverManager.getConnection("jdbc:mysql://localhost/onlineelection","root","");
            //JOptionPane.showMessageDialog(null, "Connected");
            return con; 
        } catch (SQLException ex) {
            Logger.getLogger(HeadAdminPage.class.getName()).log(Level.SEVERE, null, ex);
            //JOptionPane.showMessageDialog(null, "Not Connected");
            return null;
        }
    }

    public void Show_Data_In_Table(JTable table){
        
        String selectedOption = (String) filterComboBox.getSelectedItem();
        String selectQuery;
        
        if (selectedOption.equals("President")) {
            selectQuery = "SELECT cand_IDMatric, cand_Name, courseName, pos_name, castvote FROM candidate WHERE pos_name = 'President'";
        } else {
            selectQuery = "SELECT cand_IDMatric, cand_Name, courseName, pos_name, castvote FROM candidate WHERE pos_name = ?";
        }
        
        Connection con = getConnection();
        PreparedStatement psP;
        ResultSet rs;
        
        try {
            
            psP = con.prepareStatement(selectQuery);

            if (!selectedOption.equals("President")) {
                psP.setString(1, selectedOption);
            }
            
            rs = psP.executeQuery();
            
            DefaultTableModel tableModel = (DefaultTableModel)jTableDataP.getModel();
            
            tableModel.setRowCount(0);
            Object[] row;
            
            while(rs.next())
            {
                row = new Object[5];
                row[0] = rs.getString(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                row[4] = rs.getInt(5);

                tableModel.addRow(row);
            }               
        }catch (SQLException ex) {
            Logger.getLogger(HeadAdminPage.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    public void filterData(){
        String selectedOption = (String) filterComboBox.getSelectedItem();
        String selectQuery;
        
        if (selectedOption.equals("President")) {
            selectQuery = "SELECT cand_IDMatric, cand_Name, courseName, pos_name, castvote FROM candidate WHERE pos_name = 'President'";
        } else {
            selectQuery = "SELECT cand_IDMatric, cand_Name, courseName, pos_name, castvote FROM candidate WHERE pos_name = ?";
        }
        
        Connection con = getConnection();
        PreparedStatement psP;
        ResultSet rs;
        
        try {
            
            psP = con.prepareStatement(selectQuery);

            if (!selectedOption.equals("President")) {
                psP.setString(1, selectedOption);
            }
            
            rs = psP.executeQuery();
            
            DefaultTableModel tableModel = (DefaultTableModel)jTableDataP.getModel();
            
            tableModel.setRowCount(0);
            Object[] row;
            
            while(rs.next())
            {
                row = new Object[5];
                row[0] = rs.getString(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                row[4] = rs.getInt(5);

                tableModel.addRow(row);
            }               
        }catch (SQLException ex) {
            Logger.getLogger(HeadAdminPage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void getMostVotedCandidates() {
        
        Connection con = getConnection();
        PreparedStatement psP, psVP;
        ResultSet rsP, rsVP;

        try {
            // Get the most voted candidate for President
            String presidentQuery = "SELECT cand_Name, cand_IDMatric, courseName, castvote FROM candidate WHERE pos_name = 'President' ORDER BY castvote DESC LIMIT 1";
            psP = con.prepareStatement(presidentQuery);
            rsP = psP.executeQuery();

            if (rsP.next()) {
                String presidentID = rsP.getString("cand_IDMatric");
                String presidentName = rsP.getString("cand_Name");
                String presidentCourse = rsP.getString("courseName");
                int presidentVotes = rsP.getInt("castvote");
                
                jLabelPresident.setText(presidentName);
                jLabelPMatricId.setText(presidentID);
                jLabelPCourse.setText(presidentCourse);
                jLabelPTotVote.setText(Integer.toString(presidentVotes));
                
            }

            // Get the most voted candidate for Vice President
            String vicePresidentQuery = "SELECT cand_Name, cand_IDMatric, courseName, castvote FROM candidate WHERE pos_name = 'Vice President' ORDER BY castvote DESC LIMIT 1";
            psVP = con.prepareStatement(vicePresidentQuery);
            rsVP = psVP.executeQuery();

            if (rsVP.next()) {
                String vicePresidentID = rsVP.getString("cand_IDMatric");
                String vicePresidentName = rsVP.getString("cand_Name");
                String vicePresidentCourse = rsVP.getString("courseName");
                int vicePresidentVotes = rsVP.getInt("castvote");
                
                jLabelVPName.setText(vicePresidentName);
                jLabelVPMatricId.setText(vicePresidentID);
                jLabelVPCourse.setText(vicePresidentCourse);
                jLabelVPTotVote.setText(Integer.toString(vicePresidentVotes));
            }
        } catch (SQLException ex) {
            Logger.getLogger(HeadAdminPage.class.getName()).log(Level.SEVERE, null, ex);
        }
}

    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableDataP = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        filterComboBox = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabelPresident = new javax.swing.JLabel();
        jLabelPMatricId = new javax.swing.JLabel();
        jLabelPCourse = new javax.swing.JLabel();
        jLabelPTotVote = new javax.swing.JLabel();
        jLabelVPName = new javax.swing.JLabel();
        jLabelVPMatricId = new javax.swing.JLabel();
        jLabelVPCourse = new javax.swing.JLabel();
        jLabelVPTotVote = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(94, 250, 191));

        jPanel2.setBackground(new java.awt.Color(0, 204, 153));

        jLabel1.setFont(new java.awt.Font("Poppins SemiBold", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("FKOM ONLINE ELECTION SYSTEM 2022/2023");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(159, 159, 159)
                .addComponent(jLabel1)
                .addContainerGap(176, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel1)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 51, 51));
        jLabel2.setText("Welcome!");

        jTableDataP.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jTableDataP.setForeground(new java.awt.Color(51, 51, 51));
        jTableDataP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Matric ID", "Name", "Course", "Position", "Total Vote"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableDataP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableDataPMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTableDataP);
        if (jTableDataP.getColumnModel().getColumnCount() > 0) {
            jTableDataP.getColumnModel().getColumn(0).setResizable(false);
            jTableDataP.getColumnModel().getColumn(1).setResizable(false);
            jTableDataP.getColumnModel().getColumn(1).setPreferredWidth(100);
            jTableDataP.getColumnModel().getColumn(2).setResizable(false);
            jTableDataP.getColumnModel().getColumn(2).setPreferredWidth(200);
            jTableDataP.getColumnModel().getColumn(3).setResizable(false);
            jTableDataP.getColumnModel().getColumn(3).setPreferredWidth(80);
            jTableDataP.getColumnModel().getColumn(4).setResizable(false);
        }

        jLabel3.setFont(new java.awt.Font("Poppins Medium", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setText("View vote results for :");

        filterComboBox.setEditable(true);
        filterComboBox.setForeground(new java.awt.Color(51, 51, 51));
        filterComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "President", "Vice President" }));
        filterComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterComboBoxActionPerformed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("Matric ID                :");

        jLabel6.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 51, 51));
        jLabel6.setText("Total Vote             :");

        jLabel7.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 51, 51));
        jLabel7.setText("Course                   :");

        jLabel8.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setText("President              :");

        jLabel11.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(51, 51, 51));
        jLabel11.setText("Vice President         :");

        jLabel12.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 51, 51));
        jLabel12.setText("Matric ID                      :");

        jLabel13.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(51, 51, 51));
        jLabel13.setText("Course                         :");

        jLabel14.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(51, 51, 51));
        jLabel14.setText("Total Vote                   :");

        jLabelPresident.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabelPresident.setForeground(new java.awt.Color(51, 51, 51));
        jLabelPresident.setText(" ");

        jLabelPMatricId.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabelPMatricId.setForeground(new java.awt.Color(51, 51, 51));
        jLabelPMatricId.setText(" ");

        jLabelPCourse.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabelPCourse.setForeground(new java.awt.Color(51, 51, 51));
        jLabelPCourse.setText(" ");

        jLabelPTotVote.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabelPTotVote.setForeground(new java.awt.Color(51, 51, 51));
        jLabelPTotVote.setText(" ");

        jLabelVPName.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabelVPName.setForeground(new java.awt.Color(51, 51, 51));
        jLabelVPName.setText(" ");

        jLabelVPMatricId.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabelVPMatricId.setForeground(new java.awt.Color(51, 51, 51));
        jLabelVPMatricId.setText("   ");

        jLabelVPCourse.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabelVPCourse.setForeground(new java.awt.Color(51, 51, 51));
        jLabelVPCourse.setText("   ");

        jLabelVPTotVote.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        jLabelVPTotVote.setForeground(new java.awt.Color(51, 51, 51));
        jLabelVPTotVote.setText("   ");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jLabel7)
                    .addComponent(jLabel4)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelPresident)
                    .addComponent(jLabelPCourse)
                    .addComponent(jLabelPMatricId)
                    .addComponent(jLabelPTotVote))
                .addGap(50, 50, 50)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(jLabel12)
                    .addComponent(jLabel14)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabelVPCourse, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelVPMatricId, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelVPTotVote, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelVPName))
                .addGap(40, 40, 40))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(44, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabelVPName)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabelVPMatricId)
                        .addGap(12, 12, 12)
                        .addComponent(jLabelVPCourse)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabelVPTotVote))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabelPresident)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jLabelPMatricId)
                            .addGap(12, 12, 12)
                            .addComponent(jLabelPCourse)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jLabelPTotVote))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel8)
                                .addComponent(jLabel11))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addComponent(jLabel4)
                                    .addGap(12, 12, 12)
                                    .addComponent(jLabel7)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jLabel6))
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addComponent(jLabel12)
                                    .addGap(12, 12, 12)
                                    .addComponent(jLabel13)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jLabel14))))))
                .addGap(51, 51, 51))
        );

        jLabel9.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 51, 51));
        jLabel9.setText("ELECTION RESULTS");

        jLabel10.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 51, 51));
        jLabel10.setText("FINAL RESULTS");

        jButton4.setBackground(new java.awt.Color(204, 0, 51));
        jButton4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 16)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Log Out");
        jButton4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 692, Short.MAX_VALUE)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(353, 353, 353)
                        .addComponent(jLabel10))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(jLabel3)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(filterComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(113, 113, 113)
                                .addComponent(jLabel9))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(149, 149, 149)
                                .addComponent(jLabel2)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(363, 363, 363))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(filterComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton4)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTableDataPMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableDataPMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTableDataPMouseClicked

    private void filterComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_filterComboBoxActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:

        try{

            int confirmation = JOptionPane.showConfirmDialog(null, "Are you ure you want to logout?", "Confirmation", JOptionPane.YES_NO_OPTION);

            if (confirmation == JOptionPane.YES_OPTION){
                dispose();
                new MainMenu().setVisible(true);
            }

        }catch (Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }

    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HeadAdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HeadAdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HeadAdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HeadAdminPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HeadAdminPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> filterComboBox;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelPCourse;
    private javax.swing.JLabel jLabelPMatricId;
    private javax.swing.JLabel jLabelPTotVote;
    private javax.swing.JLabel jLabelPresident;
    private javax.swing.JLabel jLabelVPCourse;
    private javax.swing.JLabel jLabelVPMatricId;
    private javax.swing.JLabel jLabelVPName;
    private javax.swing.JLabel jLabelVPTotVote;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableDataP;
    // End of variables declaration//GEN-END:variables
}
