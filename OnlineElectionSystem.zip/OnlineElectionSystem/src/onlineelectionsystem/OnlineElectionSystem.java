/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package onlineelectionsystem;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class OnlineElectionSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("***********************Online Election System***********************");
           
        int pilih, pilih2;
        int candidateCount=0, voterCount=0, voter=0;
        int Idp = 0, pcount=0, vpcount=0;
        
        Candidate[] candidates = new Candidate[100]; //Object Array
        Candidate candidate = new Candidate();
        
        
        User[] Voters = new User[100]; //Object Array
        User user = new User();
              
        do{
            System.out.println("\n--------------------Main Menu--------------------");
            System.out.println("1. Admin");
            System.out.println("2. Head Admin");
            System.out.println("3. Voter");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            pilih = scan.nextInt();
            scan.nextLine(); // Consume the newline character
            
            switch(pilih){
                case 1:
                    
                    System.out.print("\nEnter Username : ");
                    String adminId = scan.next();
                    System.out.print("Enter Password: ");
                    String adminpass = scan.next();
                    
                    user.setId_num(adminId);
                    User admin = new Admin(adminpass,user.getId_num()); //polymorphism
                    
                    int check = ((Admin)admin).checkLogIn(); //downcasting
                    
                    if(check==1){
                        
                        do{
                            System.out.println("\n--------------------Admin Menu--------------------");
                            System.out.println("1. Add Candidate");
                            System.out.println("2. Lists of Candidate");
                            System.out.println("3. Exit");
                            System.out.print("Enter your choice: ");
                            pilih2 = scan.nextInt();
                            scan.nextLine(); // Consume the newline character

                            System.out.println("");

                            switch(pilih2){

                                case 1 -> {

                                    int choice = 1;

                                    while(choice == 1){

                                        System.out.println("Enter Candidate Information");
                                        System.out.println("-------------------------------------------------------");
                                        System.out.print("Candidate Matric ID: ");
                                        String candMatricId = scan.next();
                                        System.out.print("Candidate Name: ");
                                        scan.nextLine();
                                        String candName = scan.nextLine(); 
                                        String cname = candidate.getCcandidate().getCandidateCourse(candMatricId);

                                        System.out.println("");

                                        String jawatan[]={"President", "Vice President"};
                                        String posi = null;

                                        System.out.println("--------------------Available positions--------------------");
                                        candidate.getPosition().PrintPositions();
                                        System.out.print("\nSelect the candidate's position (1 or 2): ");
                                        int pos = scan.nextInt();

                                        int in = 1;

                                        while (in == 1){

                                            if(pos == 1){

                                                posi = jawatan[0];
                                                Idp++;
                                                pcount++;
                                                in = 0;
                                            }
                                            else if(pos == 2){

                                                posi = jawatan[1];
                                                Idp++;
                                                vpcount++;
                                                in = 0;
                                            }
                                            else{
                                                System.out.println("Incorrect Input");
                                                System.out.print("\nEnter candidate position (1 or 2): " );
                                                pos = scan.nextInt();
                                                in = 1;
                                            }
                                        }

                                        System.out.println("");

                                        candidates[candidateCount] = new Candidate( candMatricId, candName, cname, posi, Idp, 0);

                                        System.out.print("Add more candidate? (yes:1/no:0): ");
                                        choice= scan.nextInt(); 
                                        candidateCount++;
                                        System.out.println("");
                                    }
                                }

                                case 2 -> {
                                    System.out.println("\nCandidate Lists:\n");

                                    if(candidateCount>=1){
                                        System.out.println("--------------------President Position--------------------");

                                        if(pcount>= 1){
                                            candidate.displayCandidateP(candidates, candidateCount);
                                        }
                                        else{
                                            System.out.println("\nNo Candidate lists Available\n");
                                        }
                                        

                                        System.out.println("--------------------Vice President Position--------------------");       
                                        
                                        if(vpcount>= 1){
                                            candidate.displayCandidateVP(candidates, candidateCount);
                                        }
                                        else{
                                            System.out.println("\nNo Candidate lists Available\n");
                                        }
                                        
                                    }
                                    else{
                                        System.out.println("\nNo Candidate lists Available\n");
                                    }

                                }

                                case 3 -> System.out.println("Exiting the menu...");
                                default -> System.out.println("Invalid choice! Please enter a valid option.");
                            }

                        }while(pilih2!=3);                        
                        
                    }
                                        
                    break;
                 
                case 2:
                    
                    System.out.print("\nEnter Username: ");
                    String HadminId = scan.next();
                    System.out.print("Enter Password: ");
                    String Hadminpass = scan.next();
                    
                    user.setId_num(HadminId);
                    User Hadmin = new HeadAdmin(user.getId_num(), Hadminpass);//polymorphism
                    
                    int checkH = ((HeadAdmin)Hadmin).checkLogIn();//downcasting
                    
                    if(checkH==1){
                        
                        if(candidateCount>=1){
                                
                            System.out.println("--------------------------------RESULTS OF ELECTION--------------------------------");
                            System.out.println("\n---------------------COMPETING CANDIDATES FOR PRESIDENT POSITION---------------------\n");

                            if(pcount>=1){
                                candidate.getCastVote().displayPresidentResults(candidates, candidateCount);   
                            }
                            else{
                                System.out.println("No Candidate lists Available\n");
                            }

                            System.out.println("-------------------COMPETING CANDIDATES FOR VICE PRESIDENT POSITION-------------------\n");

                            if(vpcount>=1){
                                candidate.getCastVote().displayVicePresidentResults(candidates, candidateCount);
                            }
                            else{
                                System.out.println("No Candidate lists Available\n");
                            }


                            System.out.println("---------------------FINAL RESULTS---------------------\n");

                            ((HeadAdmin)Hadmin).DisplayFinalResults(candidates, candidateCount);

                        }
                        else
                        {
                            System.out.println("\nNo Results Available");
                        }

                    }
                    
                    break;
                 
                case 3: 
                    
                    int voted = 0;
                    
                    if(candidateCount>=1){
                        
                        System.out.println("\n--------------------Voter--------------------");
                        System.out.print("Enter ID Matric: ");
                        String voterMatricId = scan.next();
                        
                        //to check if the voter had voted before
                        if(voter>1){

                            for(int v=0; v < voterCount; v++){
                                                                //downcasting
                                if(voterMatricId.equals(((Voter)Voters[v]).getId_num())){
                                    System.out.println("\nVoter has voted before. Voters cannot vote more than once");
                                    voted = 1; //had voted
                                }
                            }                          
                        }

                        //if statement for first time voter
                        if (voted == 0){

                            CourseVoter cVoters =  new CourseVoter(null);
                            String VCoursename = cVoters.getVoterCourse(voterMatricId);

                            cVoters = new CourseVoter(VCoursename);
                            Voters[voterCount] = new Voter( cVoters, voterMatricId);//polymorphism
                            voterCount++; 

                            System.out.println("\nMatric ID: " + voterMatricId );
                            System.out.println("Course Name: " + VCoursename );
                            System.out.println("");
                            System.out.println("---------------------CONTESTED POSITIONS---------------------");
                            candidate.getPosition().PrintPositions();
                            System.out.println("\n");
                            System.out.println("------------------------------------------------------------");
                            System.out.println("                  YOUR VOTE IS OUR SECRET");
                            System.out.println("------------------------------------------------------------\n");
                            
                            System.out.println("---------------------COMPETING CANDIDATES FOR PRESIDENT POSITION---------------------\n");

                            if(pcount>=1){
                                
                                candidate.displayCandidateP(candidates, candidateCount);
                                System.out.print("Vote a candidate by entering Position ID :");
                                int voting = scan.nextInt();

                                int castcheckP = candidate.getCastVote().castingVotesP(candidates, candidateCount, voting);
                                
                                while(castcheckP == 0){
                                    
                                    System.out.print("Vote a candidate by entering Position ID :");
                                    voting = scan.nextInt();
                                    castcheckP = candidate.getCastVote().castingVotesP(candidates, candidateCount, voting);
                                }
                            }
                            else{
                                System.out.println("No Candidate lists Available");
                            }
                            
                            System.out.println("\n-------------------COMPETING CANDIDATES FOR VICE PRESIDENT POSITION-------------------\n");

                            if(vpcount>=1){
                                candidate.displayCandidateVP(candidates, candidateCount);
                                System.out.print("Vote a candidate by entering Position ID :");
                                int votingVP = scan.nextInt();

                                int castcheckVP = candidate.getCastVote().castingVotesVP(candidates, candidateCount, votingVP);  
                                
                                while(castcheckVP == 0){
                                    
                                    System.out.print("Vote a candidate by entering Position ID :");
                                    votingVP = scan.nextInt();
                                    castcheckVP = candidate.getCastVote().castingVotesVP(candidates, candidateCount, votingVP);  
                                }
                            }
                            else{
                                System.out.println("No Candidate lists Available\n");
                            }

                        }

                        voter = 2;

                    }
                    else{
                        System.out.println("--------------------------------------------------------");
                        System.out.println("\nNo Candidate lists Available");
                    }                   
                        
                    break;
                    
                case 4:
                    break;
            }
 
        } while(pilih!=4);
              
        
    }
        
        // TODO code application logic here
    
    
}
