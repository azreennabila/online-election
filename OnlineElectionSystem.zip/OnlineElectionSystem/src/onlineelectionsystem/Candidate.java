/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlineelectionsystem;

/**
 *
 * @author User
 */
public class Candidate {
    
    private String cand_IDMatric, cand_Name;  
    private Position position;
    private CourseCandidate Ccandidate;
    private CastVote castvote;

    public Candidate(String cand_IDMatric, String cand_Name, String courseName, String post_name, int pId, int castvotes) {
        this.cand_IDMatric = cand_IDMatric;
        this.cand_Name = cand_Name;
        //composition
        position = new Position(post_name, pId);
        castvote = new CastVote(castvotes);
        Ccandidate = new CourseCandidate(courseName);
    }

    public Candidate(CourseCandidate Ccandidate) {
        this.Ccandidate = Ccandidate;
    }

    public Candidate(){
        //composition
        position = new Position();
        castvote = new CastVote();
        this.Ccandidate = new CourseCandidate();
    }
   
    public String getCand_Name() {
        return cand_Name;
    }


    public String getCand_IDMatric() {
        return cand_IDMatric;
    }

    public void setCand_IDMatric(String cand_IDMatric) {
        this.cand_IDMatric = cand_IDMatric;
    }

    public void setCand_Name(String cand_Name) {
        this.cand_Name = cand_Name;
    }
    
    public Position getPosition(){
        return position;
    }
    
    public CourseCandidate getCcandidate(){
        return Ccandidate;
    }
    
    public CastVote getCastVote(){
        return castvote;
    }
    
    public void displayCandidateP(Candidate[] candidates, int candidateCount){
        
        int j=0;
        
        for (int i = 0; i < candidateCount; i++) {
            
            if(candidates[i].getPosition().getPost_name().equals("President")){
                System.out.println("Candidate " + (j + 1) + ":");
                System.out.println("Matric ID: " + candidates[i].cand_IDMatric);
                System.out.println("Name: " + candidates[i].cand_Name);
                System.out.println("Course: " + candidates[i].getCcandidate().getCourseName());
                System.out.println("Position: " + candidates[i].getPosition().getPost_name());
                System.out.println("Position ID: " + candidates[i].getPosition().getpId());
                System.out.println("");
                
                j++;
            }
        } 
            
    }
    
    public void displayCandidateVP(Candidate[] candidates, int candidateCount){
        
        int j=0;
        
        for (int i = 0; i < candidateCount; i++) {
            
            if(candidates[i].getPosition().getPost_name().equals("Vice President")){
                System.out.println("Candidate " + (j + 1) + ":");
                System.out.println("Matric ID: " + candidates[i].cand_IDMatric);
                System.out.println("Name: " + candidates[i].cand_Name);
                System.out.println("Course: " + candidates[i].getCcandidate().getCourseName());
                System.out.println("Position: " + candidates[i].getPosition().getPost_name());
                System.out.println("Position ID: " + candidates[i].getPosition().getpId());
                System.out.println("");
                
                j++;
            }
        } 
            
    }
    
}
