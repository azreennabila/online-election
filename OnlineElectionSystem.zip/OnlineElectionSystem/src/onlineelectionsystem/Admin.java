/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlineelectionsystem;

/**
 *
 * @author User
 */
public class Admin extends User{
    
    private String password;

    public Admin(String password, String Id_num) {
        super(Id_num);
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    @Override
    public int checkLogIn(){
        
        int log;
        
        if (getId_num().equals("Admin") && getPassword().equals("123")){
            
            System.out.println("\n---------------------Welcome---------------------\n");
            log=1;      
        }
        else
        {
            System.out.println("\nWrong username or password");
            log=0;
        }  
                  
        return log;    
    }
    
}
