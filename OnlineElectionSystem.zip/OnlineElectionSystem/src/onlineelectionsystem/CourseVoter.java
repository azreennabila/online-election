/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlineelectionsystem;

/**
 *
 * @author User
 */
public class CourseVoter {
    
    private String courseName;

    public CourseVoter(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
    
    public String getVoterCourse(String voterID){
        
        String ID = voterID.substring(0,2);
        
        String programFKOM[]={"Diploma","Computer System and Networking", "Graphic and Multimedia", "Software Engineering", "Cyber Security"};

        if(ID.equals("CC")){
            courseName = programFKOM[0];
        }
        else if (ID.equals("CA")){
            courseName = programFKOM[1];
        }
        else if (ID.equals("CD")){
            courseName = programFKOM[2];
        }
        else if (ID.equals("CB")){
            courseName = programFKOM[3];
        }
        else if (ID.equals("CY")){
            courseName = programFKOM[4];
        }
        
        return courseName;
        
    }
    
}
