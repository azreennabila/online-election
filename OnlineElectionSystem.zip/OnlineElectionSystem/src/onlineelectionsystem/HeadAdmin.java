/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlineelectionsystem;

/**
 *
 * @author User
 */
public class HeadAdmin extends User{
    
     private String HeadPass;

    public HeadAdmin(String Id_num, String HeadPass) {
        super(Id_num);
        this.HeadPass = HeadPass;
    }

    public String getHeadPass() {
        return HeadPass;
    }

    public void setHeadPass(String HeadPass) {
        this.HeadPass = HeadPass;
    }
    
    @Override
    public int checkLogIn(){
        
        int log;
        
        if (getId_num().equals("HeadAdmin") && getHeadPass().equals("123")){
            
            System.out.println("\n---------------------Welcome---------------------\n");
            log=1;      
        }
        else
        {
            System.out.println("\nWrong username or password");
            log=0;
        }  
                  
        return log; 
        
    }
        
    public void DisplayFinalResults(Candidate[] candidates, int candidateCount){
        
        Candidate[] presidentvote = new Candidate[100];
        Candidate[] vicepresidentvote = new Candidate[100];
        
        int j=0, k=0;
        
        for (int i = 0; i < candidateCount; i++){    
            if(candidates[i].getPosition().getPost_name().equals("President")){
                
                presidentvote[j] = new Candidate();
                
                presidentvote[j].setCand_Name(candidates[i].getCand_Name());
                presidentvote[j].setCand_IDMatric(candidates[i].getCand_IDMatric());
                presidentvote[j].getPosition().setPost_name(candidates[i].getPosition().getPost_name());
                presidentvote[j].getCcandidate().setCourseName(candidates[i].getCcandidate().getCourseName());
                presidentvote[j].getCastVote().setCastvote(candidates[i].getCastVote().getCastvote());
                
                j++; 
            } 

            if(candidates[i].getPosition().getPost_name().equals("Vice President")){
                
                vicepresidentvote[k] = new Candidate();
                
                vicepresidentvote[k].setCand_Name(candidates[i].getCand_Name());
                vicepresidentvote[k].setCand_IDMatric(candidates[i].getCand_IDMatric());
                vicepresidentvote[k].getPosition().setPost_name(candidates[i].getPosition().getPost_name());
                vicepresidentvote[k].getCcandidate().setCourseName(candidates[i].getCcandidate().getCourseName());
                vicepresidentvote[k].getCastVote().setCastvote(candidates[i].getCastVote().getCastvote());
                k++; 
            } 
        }
        
        if(j>=1){
            
            int totP = presidentvote[0].getCastVote().getCastvote(), totVoteP=0;
            
            for (int i = 0; i < j; i++) {

                if(presidentvote[i].getPosition().getPost_name().equals("President")){
                    if(presidentvote[i].getCastVote().getCastvote()> totP ){
                        totP = presidentvote[i].getCastVote().getCastvote();
                        totVoteP = i;
                    }  
                }                
            }
            
            System.out.println("President : " + presidentvote[totVoteP].getCand_Name());
            System.out.println("Matric ID : " + presidentvote[totVoteP].getCand_IDMatric());
            System.out.println("Course    : " + presidentvote[totVoteP].getCcandidate().getCourseName());
            System.out.println("Total Vote: " + presidentvote[totVoteP].getCastVote().getCastvote());  
            System.out.println("\n");
        }  
        
        if(k>=1){
            
            int totVP = vicepresidentvote[0].getCastVote().getCastvote(), totVoteVP=0;
            
            for (int i = 0; i < k; i++) {

                if(vicepresidentvote[i].getPosition().getPost_name().equals("Vice President")){
                    if(vicepresidentvote[i].getCastVote().getCastvote()> totVP ){
                        totVP = vicepresidentvote[i].getCastVote().getCastvote();
                        totVoteVP = i;
                    }  
                }
            }
            
            System.out.println("Vice President : " + vicepresidentvote[totVoteVP].getCand_Name());
            System.out.println("Matric ID : " + vicepresidentvote[totVoteVP].getCand_IDMatric());
            System.out.println("Course    : " + vicepresidentvote[totVoteVP].getCcandidate().getCourseName());
            System.out.println("Total Vote: " + vicepresidentvote[totVoteVP].getCastVote().getCastvote()); 
        }    

    }
    
}
